from rubpy.rubika import Rubika
from rubpy.socket.Socket import Socket

__version__ : str = '3.0.0'
__author__ : str = 'Mahdi Vazini'
